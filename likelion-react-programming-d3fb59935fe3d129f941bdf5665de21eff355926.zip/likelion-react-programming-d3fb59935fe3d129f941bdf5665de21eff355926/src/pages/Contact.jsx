function Contact() {
  return (
    <div>
      <h1 className="text-emerald-500">Contact</h1>
    </div>
  );
}

export default Contact;
