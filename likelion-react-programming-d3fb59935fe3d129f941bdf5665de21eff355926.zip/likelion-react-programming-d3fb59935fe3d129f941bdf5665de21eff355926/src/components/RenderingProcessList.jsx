function RenderingProcessList() {
  return (
    <ol>
      <li>렌더 트리거</li>
      <li>컴포넌트 렌더링</li>
      <li>DOM 커밋</li>
    </ol>
  );
}

export default RenderingProcessList;
