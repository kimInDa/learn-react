function Description() {
  return <p>리액트는 프론트엔드 개발 분야 No.1 UI 라이브러리입니다.</p>;
}

export default Description;