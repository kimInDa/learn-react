function Contact() {
  return (
    <>
      <h2>문의 페이지</h2>
    </>
  );
}

export default Contact;
