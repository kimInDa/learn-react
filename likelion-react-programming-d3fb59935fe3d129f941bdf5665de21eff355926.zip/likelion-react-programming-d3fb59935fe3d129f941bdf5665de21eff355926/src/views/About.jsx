function About() {
  return (
    <>
      <h2>소개 페이지</h2>
    </>
  );
}

export default About;
