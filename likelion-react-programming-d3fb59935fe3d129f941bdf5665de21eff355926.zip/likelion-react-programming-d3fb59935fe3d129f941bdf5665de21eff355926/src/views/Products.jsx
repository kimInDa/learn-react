function Products() {
  return (
    <>
      <h2>제품 목록 페이지</h2>
    </>
  );
}

export default Products;
